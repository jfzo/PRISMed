PRISMed Qt - Client
=======================

Server unit of the PRISMed platform.

Installing PyQt in OSX
======================

It is strongly recommended to install through anaconda.



