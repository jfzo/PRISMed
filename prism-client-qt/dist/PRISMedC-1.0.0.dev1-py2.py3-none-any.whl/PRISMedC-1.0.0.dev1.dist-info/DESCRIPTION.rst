PRISMed Qt - Client
=======================

Qt client made for the PRISMed platform.

Installing PyQt in OSX
======================

It is strongly recommended to install through anaconda.

conda install -c anaconda pyqt=4.11.4

*Replace the version with the one you need from the list resulting from the command*

conda search pyqt


